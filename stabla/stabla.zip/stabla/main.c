#include <stdio.h>
#include <stdlib.h>
#include "stabla.h"

int main()
{
    cvor *koren = NULL, *tek = NULL;
    int n, a;

    scanf("%d", &n);
    for(int i=0; i<n; i++){
        scanf("%d", &a);
        dodaj_u_stablo(&koren, a);
    }
    ispis_lkd(koren);
    printf("\n");

    tek = min(koren);

    brisi(&koren, 1);
    ispis_lkd(koren);
    printf("\n");
    return 0;
}
