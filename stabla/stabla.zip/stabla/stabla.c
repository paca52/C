#include "stabla.h"
#include <stdio.h>
#include <stdlib.h>

cvor *napravi_cvor(int broj){
    cvor *novi = (cvor*)malloc(sizeof(cvor));
    if(novi == NULL) return NULL;

    novi->broj = broj;
    novi->levo = NULL;
    novi->desno = NULL;

    return novi;
}

void dodaj_u_stablo(cvor **koren, int broj){
    if(*koren == NULL){
        cvor *novi = napravi_cvor(broj);
        *koren = novi;
        return;
    }
    if(broj < (*koren)->broj)
        dodaj_u_stablo(&(*koren)->levo, broj);
    else
        dodaj_u_stablo(&(*koren)->desno, broj);
}

//vraca pokazivac na cvor
cvor *pretrazi(cvor *koren, int broj){
    if(koren == NULL)
        return NULL;
    if(koren->broj == broj)
        return koren;
    if(koren->broj < broj)
        return pretrazi(koren->desno, broj);
    else
        return pretrazi(koren->levo, broj);
}

void ispis_lkd(cvor *koren){
    if(koren != NULL){
        ispis_lkd(koren->levo);
        printf("%d ", koren->broj);
        ispis_lkd(koren->desno);
    }
}

cvor *min(cvor *koren){
    if(koren == NULL) return NULL;
    if(koren->levo == NULL)
        return koren;
    return min(koren->levo);
}

void brisi(cvor **koren,int broj)
{
    cvor *tmp=NULL;
    if(*koren==NULL)
        return;
    if(broj<(*koren)->broj)
    {
        brisi(&(*koren)->levo,broj);
        return;
    }
    if((*koren)->broj<broj)
    {
        brisi(&(*koren)->desno,broj);
        return;
    }
    if((*koren)->levo==NULL && (*koren)->desno==NULL)
    {
        free(*koren);
        *koren=NULL;
        return;
    }
    if((*koren)->levo!=NULL && (*koren)->desno==NULL)
    {
        tmp=(*koren)->levo;
        free(*koren);
        *koren=tmp;
        return;
    }
    if((*koren)->levo==NULL && (*koren)->desno!=NULL)
    {
        tmp=(*koren)->desno;
        free(*koren);
        *koren=tmp;
        return;
    }
    tmp=min((*koren)->desno);
    (*koren)->broj=tmp->broj;
    tmp->broj=broj;
    brisi(&(*koren)->desno,broj);
}
