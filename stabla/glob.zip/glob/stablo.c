#include <stdio.h>
#include <stdlib.h>
#include "stabla.h"

int brojlistova(cvor *koren){
    if(koren == NULL) return 0;
    if(koren->levo == NULL && koren->desno == NULL)
        return 1;
    else
        return brojlistova(koren->levo) + brojlistova(koren->desno);
}

void PozVredListovaStabla(cvor *koren){
    if(koren == NULL) return;
    if(koren->levo == NULL && koren->desno == NULL && koren->broj>0){
        printf("%d ", koren->broj);
        return;
    }
    else{
        PozVredListovaStabla(koren->levo);
        PozVredListovaStabla(koren->desno);
    }
}

int max(int a, int b){
    if(a > b)
        return a;
    return b;
}

int dubina(cvor *koren){
    if(koren == NULL) return 0;
    return 1 + max(dubina(koren->desno), dubina(koren->levo));
}

int brojCvorovaNiv(cvor *koren, int i, int k){
    if(koren == NULL)
        return 0;
    if(i == k) return 1;
    else
        return brojCvorovaNiv(koren->desno, i+1, k) + brojCvorovaNiv(koren->levo, i+1, k);
}
