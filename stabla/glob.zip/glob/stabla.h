#ifndef STABLA_H_INCLUDED
#define STABLA_H_INCLUDED

typedef struct cvor{
    int broj;
    struct cvor *levo;
    struct cvor *desno;
}cvor;

cvor *napravi_cvor(int broj);

void dodaj_u_stablo(cvor **koren, int broj);

//vraca pokazivac na cvor
cvor *pretrazi(cvor *koren, int broj);

void ispis_lkd(cvor *koren);

cvor *min(cvor *koren);

void brisi(cvor **koren,int broj);


#endif // STABLA_H_INCLUDED
