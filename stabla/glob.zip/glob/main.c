#include <stdio.h>
#include <stdlib.h>
#include "stablo.c"

int main()
{
    cvor *koren = NULL;
    int n, a;
    scanf("%d", &n);
    while(n--){
        scanf("%d", &a);
        dodaj_u_stablo(&koren, a);
    }

    printf("broj listova: %d\n", brojlistova(koren));

    PozVredListovaStabla(koren);
    printf("\n");

    printf("dubina stabla: %d\n", dubina(koren));

    printf("unesi nivo: ");
    int i;
    scanf("%d", &i);
    printf("broj cvorova na %d-om nivou: %d\n", i, brojCvorovaNiv(koren, 0, i));

    return 0;
}
